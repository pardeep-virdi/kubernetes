#!/bin/bash
echo 'export PATH=$PATH:~/odev/bin/' >> ~/.bashrc
